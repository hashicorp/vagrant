from command_line import CommandLineLoader
from dict import DictLoader
from file import ConfigFileLoader, PythonFileLoader, PythonModuleLoader
